<!-- <script>
        var buttons = document.querySelectorAll('.common-class');
        
        var clickedRow = buttons.parentNode;
       

  // Disable all buttons in the clicked row
  var buttonsInRow = clickedRow.querySelectorAll('.common-class');
  buttonsInRow.forEach(function(button) {
    
        console.log(button)
      button.disabled = true;
   
  

    

  });


// Attach click event listener to each button
buttons.forEach(function(button) {
  button.addEventListener('click', handleClick);
});
    </script> -->

    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Document</title>
    </head>
    <body>
      <form action="/dt_tst/53" method="get">
        <input type="submit" value="submit">
      </form>
    </body>
    </html>