
           <h1> Hi, <?php echo e($username); ?></h1>

           <h2> You Reported To This Email id :<b> &nbsp;<?php echo e($mail2); ?>  </b></h2>
<h3>The Answer Is 
    // <?php echo e(strip_tags($answ)); ?>  
    <span style="background: red; color:white;" ><?php echo e(strip_tags($answ)); ?></span>
</h3>
           <br>
            <h4>We Reviewed Your Report and We Chose This : <?php echo e($reason); ?></h4>
            
     <?php /**PATH C:\xampp\htdocs\Answerbag\major_project\resources\views/admin/mail.blade.php ENDPATH**/ ?>