<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Custom Registration & Login </title>
    <link rel="stylesheet" href="<?php echo e(asset('nancy_css\style.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        
</head>

<body>

    <nav class="navbar navbar-expand-lg " style="background-color:orange;">


        <div class="text-center navbar-brand-wrapper mx-5 d-flex align-items-center justify-content-start"
            style="background-color:orange;">
            <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-start">
            <a class="navbar-brand brand-logo me-5" href="index.html"><img
                            src="<?php echo e(asset('nancy_css\images/logo.png')); ?>" class="me-2"
                            alt="logo" /></a>
               
            </div>
        </div>
        
        <a class="navbar-brand " href="<?php echo e(URL('/')); ?>">
            <h4 class="text-center" style="font-family: 'Times New Roman', Times, serif;">Admin Login Register</h4>
        </a>
        
        
        

        <div class="collapse navbar-collapse me-5" id="navbarNavDropdown" style="font-family: 'Times New Roman', Times, serif;">
            <ul class="navbar-nav ms-auto">
                <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e((request()->is('login')) ? 'active' : ''); ?>" href="<?php echo e(route('login')); ?>">
                        <button type="button" class="btn btn-dark btn-outline-white  me-2">Login</button>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e((request()->is('register')) ? 'active' : ''); ?>"
                        href="<?php echo e(route('register')); ?>"> <button type="button"
                            class="btn btn-warning  me-3">Register</button></a>
                </li>
                <?php else: ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <?php echo e(Auth::user()->name); ?>

                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                            <button type="button" class="btn btn-dark btn-outline-white  me-2">Logout</button>
                        </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>

        </div>


    </nav>


    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\Answerbag\major_project\resources\views/auth/layouts.blade.php ENDPATH**/ ?>